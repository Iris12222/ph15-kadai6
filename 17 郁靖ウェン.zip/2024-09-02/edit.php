<?php


require_once __DIR__ . '/functions/user.php';


session_start();

if (!isset($_SESSION['id']) && !isset($_COOKIE['id'])) {
    header('Location: ./login.php');
    exit();
}

$id = $_SESSION['id'] ?? $_COOKIE['id'];

if (isset($_POST['submit-button'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];


    $user = [
        'id' => $id,
        'name' => $name,
        'email' => $email,
        'password' => $password,
    ];

    $user = saveUser($user);

    $_SESSION['id'] = $user['id'];

    header('Location: ./my-page.php');
    exit();
}

?>
<html>
    <head>
        <style>
                            .error {
                color: red;
            }

            body {
                background-color: pink;
                text-align: center;
                margin: 0 auto;
                margin-top: 300px;
            }
        </style>
    </head>
    <body>
        <h1>情報変更</h1>
        <form action="./edit.php" method="post">
            <div>
                お名前<br>
                <input type="text" name="name">
            </div>
            <div>
                メールアドレス<br>
                <input type="email" name="email" required>
            </div>
            <div>
                パスワード<br>
                <input type="password" name="password">
            </div>
            <div>
                <!-- <button type="submit">登録</button> -->
                <input type="submit" value="登録" name="submit-button">
            </div>
        </form>
        <footer>
             <p>© 2024 PH15 HAL東京</p>
        </footer>
    </body>
</html>
