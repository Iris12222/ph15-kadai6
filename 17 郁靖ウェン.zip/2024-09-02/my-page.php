<?php

require_once __DIR__ . '/functions/user.php';

session_start();

if (!isset($_SESSION['id']) && !isset($_COOKIE['id'])) {
    header('Location: ./login.php');
    exit();
}

$id = $_SESSION['id'] ?? $_COOKIE['id'];

$user = getUser($id);

if (is_null($user)) {
    header('Location: ./login.php');
    exit();
}

?>
<html>
    <head>
        <style>
    .error {
                color: red;
            }

            body {
                background-color: pink;
                text-align: center;
                margin: 0 auto;
                margin-top: 300px;
            }
            </style>
    </head>
    <body>
        <h1>マイページ</h1>
        <table>
            <tr>
                <td>ID</td>
                <td>
                    <?php echo $user['id'] ?>
                </td>
            </tr>
            <tr>
                <td>名前</td>
                <td>
                    <?php echo $user['name'] ?>
                </td>
            </tr>
            <tr>
                <td>メールアドレス</td>
                <td></td>
            </tr>
        </table>
        <div>
            <a href="./edit.php">
                情報変更
            </a>
        </div>
        <div>
            <a href="./logout.php">
                ログアウト
            </a>
        </div>
        <footer>
             <p>© 2024 PH15 HAL東京</p>
        </footer>
    </body>
</html>
